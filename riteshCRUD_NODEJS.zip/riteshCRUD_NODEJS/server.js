const express = require('express')
const dotenv = require('dotenv').config()
const mongoose = require('mongoose')
var http = require('http')
var cors = require('cors')
const crud = require('./routes/crud')

const app = express()

var corsOptions = {
  origin: '*',
}

app.use(cors(corsOptions))

// parse requests of content-type - application/json
app.use(express.json())

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }))

app.get('/', (req, res) => {
  res.json({ message: 'You are in Home Page' })
})

// ========== External Routes ==========
app.use('/api', crud)

// set port, listen for requests
const PORT = process.env.PORT || 5000

mongoose
  .connect('mongodb://localhost:27017/crudDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    var server = http.createServer(app)
    server.listen(PORT, function () {
      console.log('Express server listening on port ' + PORT)
    })
  })
  .catch((err) => {
    console.log(err)
  })

module.exports = app
