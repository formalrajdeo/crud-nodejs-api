const mongoose = require('mongoose')

const schema = mongoose.Schema({
  name: { type: String },
  address: { type: String },
  state: { type: String },
})

module.exports = mongoose.model('crudSchema', schema)
