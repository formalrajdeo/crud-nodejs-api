const express = require('express')
let router = express.Router()
const crudSchema = require('../Schema/crudSchema')

router.route('/crud').post(async (req, res) => {
  // Create a CRUD
  const crud = {
    ...req.body,
  }

  let crudModel = new crudSchema(crud)
  // Save Role in the database
  crudModel
    .save()
    .then((doc) => {
      res.send({
        success: true,
        results: doc,
      })
    })
    .catch((err) => {
      console.error(err)
      res.status(500).send({
        success: false,
        message: err || 'Some error occurred while creating the Role.',
      })
    })
})
router.route('/crud/:id').get(async (req, res) => {
  let id = req.params.id

  crudSchema
    .findOne({ _id: id })
    .then((doc) => {
      res.send({
        success: true,
        results: doc,
        message: `Record fetched successfully...`,
      })
    })
    .catch((err) => {
      res.status(500).send({
        success: false,
        message: err || 'Records were not found.',
      })
    })
})
router.route('/crud').get(async (req, res) => {
  crudSchema
    .find({})
    .then((doc) => {
      res.send({
        success: true,
        results: doc,
        message: `All records fetched successfully...`,
      })
    })
    .catch((err) => {
      res.status(500).send({
        success: false,
        message: err || 'Records were not found.',
      })
    })
})
router.route('/crud/:id').put(async (req, res) => {
  const id = req.params.id

  crudSchema
    .updateOne({ _id: id }, req.body)
    .then((doc) => {
      console.log(doc)
      res.send({
        success: true,
        results: doc,
      })
    })
    .catch((err) => {
      console.error(err)
      res.status(500).send({
        success: false,
        message: err.message || `Failed to update...`,
      })
    })
})
router.route('/crud/:id').delete(async (req, res) => {
  let id = req.params.id
  crudSchema
    .deleteOne({ _id: id })
    .then((nums) => {
      console.log('Deleted  record successfully...')
      res.send({
        success: true,
        results: nums,
        message: `Record deleted successfully!`,
      })
    })
    .catch((err) => {
      res.status(500).send({
        success: false,
        message: err || 'Some error occurred while removing all users.',
      })
    })
})

router.route('/crud').delete(async (req, res) => {
  crudSchema
    .deleteMany()
    .then((nums) => {
      console.log('Deleted all records successfully...')
      res.send({
        success: true,
        results: nums,
        message: `Records were deleted successfully!`,
      })
    })
    .catch((err) => {
      res.status(500).send({
        success: false,
        message: err || 'Some error occurred while removing all users.',
      })
    })
})

module.exports = router
